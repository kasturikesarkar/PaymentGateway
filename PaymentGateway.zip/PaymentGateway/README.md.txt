PaymentGateway.sln contains two projects - PaymentGateway and PaymentGatewayTests

PaymentGateway: 
	PaymentGatewayController - 
		Two endpoints included- Post and Get By Id.
		FluentValidation for the input fields 
		Validation Errors returned back as 422 unprocessable enity with descriptive messages
	PaymentGatewayService - 
		Uses EntityFrameworkCore Inmemory to store and get data

PaymentGatewayTests:
	XUnit Tests included 