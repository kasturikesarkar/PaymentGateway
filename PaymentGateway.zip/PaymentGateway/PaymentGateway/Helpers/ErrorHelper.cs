﻿using FluentValidation.Results;

namespace PaymentGateway.Helpers
{
    public static class ErrorHelper
    {
        public static Dictionary<string, string[]> GetErrorList(ValidationResult results)
        {
            var errors = results.Errors
            .GroupBy(x => x.PropertyName)
            .ToDictionary(
                x => x.Key,
                x => x.Select(validationFailure => validationFailure.ErrorMessage).ToArray());
            return errors;
        }
    }
}
