﻿using PaymentGateway.Enums;

namespace PaymentGateway.Models;

public class PaymentGatewayResponse
{
    public Guid Id { get; set; }
    public string Status { get; set; }
    public string? CardNumber { get; set; }
    public int ExpiryMonth { get; set; }
    public int ExpiryYear { get; set; }
    public string? Currency { get; set; }
    public int Amount { get; set; }
}
