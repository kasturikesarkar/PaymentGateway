﻿using PaymentGateway.Data;
using PaymentGateway.Models;
using System.Net;
using AutoMapper;
using Microsoft.OpenApi.Extensions;

namespace PaymentGateway.Services;

public class PaymentGatewayService : IPaymentGatewayService
{
    private readonly ILogger _logger;
    private AppDbContext _appDbContext;
    private readonly IMapper _mapper;

    public PaymentGatewayService( ILogger<PaymentGatewayService> logger, AppDbContext appDbContext, IMapper mapper)
    {
        _logger = logger;
        _appDbContext = appDbContext;
        _mapper = mapper;
    }

    public PaymentGatewayResponse? GetPaymentGatewayDetails(Guid id)
    {
        var result = _appDbContext.PaymentGatewayDetails.Where(x => x.Id == id).FirstOrDefault();
        result!.CardNumber = result.CardNumber!.Substring(result.CardNumber.Length - 4);
        return _mapper.Map<PaymentGatewayResponse>(result);
    }


    public async Task<PaymentGatewayResponse> ProcessPayment(PaymentGatewayRequest model, CancellationToken cancellationToken)
    {
        _logger.LogInformation("ProcessPayment for {Model}", model);
        try
        {
            var payment = _mapper.Map<PaymentGatewayDetail>(model);
            payment.Id = Guid.NewGuid();
            payment.Status = Enums.Status.Authorized.GetDisplayName();
            _appDbContext.PaymentGatewayDetails.Add(payment);
            await _appDbContext.SaveChangesAsync();
            var result = _appDbContext.PaymentGatewayDetails.Where(x => x.Id == payment.Id).FirstOrDefault();
            result!.CardNumber = result.CardNumber!.Substring(result.CardNumber.Length - 4);
            return _mapper.Map<PaymentGatewayResponse>(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ProcessPayment Error");
            throw new WebException("Exception occured in ProcessPayment", ex);
        }
    }
}
