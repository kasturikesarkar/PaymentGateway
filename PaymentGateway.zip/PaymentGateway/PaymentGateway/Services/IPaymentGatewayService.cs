﻿using PaymentGateway.Models;

namespace PaymentGateway.Services;

public interface IPaymentGatewayService
{
    PaymentGatewayResponse? GetPaymentGatewayDetails(Guid id);
    Task<PaymentGatewayResponse> ProcessPayment(PaymentGatewayRequest model, CancellationToken cancellationToken);
}