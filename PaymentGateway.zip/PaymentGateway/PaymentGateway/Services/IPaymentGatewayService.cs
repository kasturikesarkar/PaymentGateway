﻿using PaymentGateway.Models;

namespace PaymentGateway.Services;

public interface IPaymentGatewayService
{
    PaymentGatewayResponse? GetPaymentGatewayDetails(Guid id);
    List<PaymentGatewayDetail>? GetAllPaymentGatewayDetails();
    Task<PaymentGatewayResponse> ProcessPayment(PaymentGatewayRequest model, CancellationToken cancellationToken);
}