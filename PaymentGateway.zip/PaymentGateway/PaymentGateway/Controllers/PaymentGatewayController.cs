using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using PaymentGateway.Helpers;
using PaymentGateway.Models;
using PaymentGateway.Services;

namespace PaymentGateway.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PaymentGatewayController : ControllerBase
    {       

        private readonly ILogger<PaymentGatewayController> _logger;
        private readonly IPaymentGatewayService _service;
        private readonly IValidator<PaymentGatewayRequest> _validator;

        public PaymentGatewayController(ILogger<PaymentGatewayController> logger, IPaymentGatewayService service, IValidator<PaymentGatewayRequest> validator)
        {
            _logger = logger;
            _service = service;
            _validator = validator;
        }
        [HttpPost("ProcessPayment")]
        public async Task<IActionResult> ProcessPayment([FromBody] PaymentGatewayRequest request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("ProcessPayment");
            try
            {
                if (request == null)
                {
                    return new BadRequestObjectResult("Process Payment InComplete");
                }
                ValidationResult results = await _validator.ValidateAsync(request, cancellationToken);
                if (results.IsValid)
                {
                    return new CreatedResult("", await _service.ProcessPayment(request, cancellationToken));
                }
                else
                {
                    return new UnprocessableEntityObjectResult(ErrorHelper.GetErrorList(results));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ProcessPayment Error");
                return Problem("Error occured while processing the request");
            }
        }
        [HttpGet("GetPaymentDetails/{id:Guid}\"")]
        public IActionResult GetPaymentDetails(Guid id)
        {
            _logger.LogInformation("GetPaymentDetails");
            try
            {
                return new AcceptedResult("", _service.GetPaymentGatewayDetails(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetPaymentDetails Error");
                return Problem("Error occured while processing the request");
            }
        }
    }
}
