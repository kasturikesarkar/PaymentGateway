﻿namespace PaymentGateway.Enums;

public enum Status
{
    Authorized,
    Declined
}