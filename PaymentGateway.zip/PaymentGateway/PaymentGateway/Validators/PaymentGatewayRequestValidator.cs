﻿using FluentValidation;
using PaymentGateway.Models;

namespace PaymentGateway.Validators
{
    public class PaymentGatewayRequestValidator :AbstractValidator<PaymentGatewayRequest>
    {
        public PaymentGatewayRequestValidator()
        {
            RuleFor(x => x.CardNumber).NotEmpty()
                .WithMessage("CardNumber must not be empty")
                .MinimumLength(14)
                .WithMessage("CardNumber must be atleast 14 characters long")
                .MaximumLength(19)
                .WithMessage("CardNumber must be upto 19 characters long")
               ;
            ;
            RuleFor(x => x.ExpiryMonth).NotEmpty()
                .WithMessage("ExpiryMonth must not be empty")
                .InclusiveBetween(1,12).WithMessage("ExpiryMonth must between 1 and 12");
            RuleFor(x => x.ExpiryYear).NotEmpty()
                .WithMessage("ExpiryYear must not be empty")
                .GreaterThanOrEqualTo(DateTime.Now.Year).WithMessage("ExpiryYear must be greater than or equal to current year");
            RuleFor(x => x.ExpiryYear).GreaterThan(DateTime.Now.Year).When(x => x.ExpiryMonth <= DateTime.Now.Month)
                .WithMessage("ExpiryYear must not be in future");
            RuleFor(x => x.ExpiryMonth).GreaterThan(DateTime.Now.Month).When(x => x.ExpiryYear == DateTime.Now.Year)
                .WithMessage("ExpiryMonth must not be in future");
            RuleFor(x => x.Currency).NotEmpty()
                .WithMessage("Currency must not be empty").Length(3)
                .WithMessage("Currency must be 3 characters long");
            RuleFor(x => x.Amount).NotEmpty()
                .WithMessage("Amount must not be empty");
            RuleFor(x => x.Cvv).NotEmpty()
                .WithMessage("Cvv must not be empty")
                .MinimumLength(3)
                .WithMessage("Cvv must be atleast 3 characters long")
                .MaximumLength(4)
                .WithMessage("Cvv must be upto 4 characters long")
                .Must(x => int.TryParse(x, out var val) && val > 0)
                .WithMessage("Cvv is an invalid number"); 
            
        }
    }
}
