﻿using AutoMapper;
using Microsoft.OpenApi.Extensions;
using PaymentGateway.Enums;
using PaymentGateway.Models;

namespace PaymentGateway.Mappers
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<PaymentGatewayRequest, PaymentGatewayDetail>();
            CreateMap<PaymentGatewayDetail, PaymentGatewayResponse>();
        }
    }
}
