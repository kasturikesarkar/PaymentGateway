﻿using AutoFixture;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.Client;
using PaymentGateway.Controllers;
using PaymentGateway.Models;

namespace PaymentGatewayTests.Services
{
    public class PaymentGatewayServiceTests
    {
        //public PaymentGatewayServiceTests()
        //{
        //    _fixture = new Fixture();
        //    _controller = new PaymentGatewayController(_logger.Object, _service.Object, _validator.Object);
        //    _request = _fixture.Create<PaymentGatewayRequest>();
        //    _response = _fixture.Create<PaymentGatewayResponse>();
        //}
        //[Fact]
        //public async Task PostPaymentRequest_Success()
        //{
        //    _service.Setup(s => s.ProcessPayment(_request!, CancellationToken.None)).ReturnsAsync(_response);
        //    var validationResults = new ValidationResult();
        //    _validator.Setup(x => x.ValidateAsync(_request!, CancellationToken.None)).ReturnsAsync(validationResults);

        //    var result = await _controller!.ProcessPayment(_request!, CancellationToken.None);
        //    Assert.NotNull(((ObjectResult)result).Value);
        //}
    }
}
