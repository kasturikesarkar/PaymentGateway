﻿using AutoFixture;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.EntityFrameworkCore;
using PaymentGateway.Data;
using PaymentGateway.Mappers;
using PaymentGateway.Models;
using PaymentGateway.Services;


namespace PaymentGatewayTests.Services
{
    public class PaymentGatewayServiceTests
    {
        private readonly Mock<ILogger<PaymentGatewayService>> _logger = new Mock<ILogger<PaymentGatewayService>>();
        private IMapper? mapper;
        private Mock<AppDbContext>  mockContext = new Mock<AppDbContext>();
        private PaymentGatewayService? _service;
        private Fixture? _fixture;

        public PaymentGatewayServiceTests()
        {

            _fixture = new Fixture();
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new MapperProfile());
            });
            mapper = config.CreateMapper();           
        }
        [Fact]
        public void GetPayment_Success()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDB")
            .Options;
            var id = Guid.NewGuid();
            var _request = new PaymentGatewayRequest { CardNumber = "1234567891234567", Amount = 1, Currency = "GBP", ExpiryMonth = 1, ExpiryYear = 2025 };
            var myDbContextMock = new Mock<AppDbContext>(options);
            var entities = new List<PaymentGatewayDetail>
            {
                 new PaymentGatewayDetail { CardNumber="1234567891234567", Amount=1, Currency="GBP", ExpiryMonth=1, ExpiryYear=2025, Id=id, Cvv="123", Status=PaymentGateway.Enums.Status.Authorized}
            };
            myDbContextMock.Setup(x => x.PaymentGatewayDetails).ReturnsDbSet(entities);
            _service = new PaymentGatewayService(_logger.Object, myDbContextMock.Object, mapper!);

            var result =  _service!.GetPaymentGatewayDetails(entities[0].Id);
            Assert.NotNull(result);
        }
    }
}
