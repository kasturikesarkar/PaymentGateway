﻿using AutoFixture;
using AutoMapper;
using PaymentGateway.Mappers;
using PaymentGateway.Models;

namespace PaymentGatewayTests.Mappers
{
    public class MapperProfileTests
    {
        private IMapper _mapper = null!;
        private IFixture _fixture = null!;
        public MapperProfileTests()
        {
            var mappingConfig = new MapperConfiguration(cfg => cfg.AddProfile(new MapperProfile()));
            _mapper = mappingConfig.CreateMapper();
            _fixture = new Fixture();
        }

        [Fact]
        public void GivenRequest_ShouldMap_ToDetails()
        {
            //Arrange
            var request = _fixture.Create<PaymentGatewayRequest>();
            // Act
            var result = _mapper.Map<PaymentGatewayRequest, PaymentGatewayDetail>(request);

            // Assert
            Assert.Equal(result.CardNumber, request.CardNumber);
        }
        [Fact]
        public void GivenDetail_ShouldMap_ToResponse()
        {
            //Arrange
            var request = _fixture.Create<PaymentGatewayDetail>();
            // Act
            var result = _mapper.Map<PaymentGatewayDetail, PaymentGatewayResponse>(request);

            // Assert
            Assert.Equal(result.CardNumber, request.CardNumber);
        }
    }
}
