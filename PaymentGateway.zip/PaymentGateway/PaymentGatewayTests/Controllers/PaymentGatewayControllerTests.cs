﻿

using AutoFixture;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using PaymentGateway.Controllers;
using PaymentGateway.Models;
using PaymentGateway.Services;

namespace PaymentGatewayTests.Controllers
{
    public class PaymentGatewayControllerTests
    {
        private readonly Mock<ILogger<PaymentGatewayController>> _logger = new Mock<ILogger<PaymentGatewayController>>();
        private readonly Mock<IPaymentGatewayService> _service = new Mock<IPaymentGatewayService>();
        private readonly Mock<IValidator<PaymentGatewayRequest>> _validator = new Mock<IValidator<PaymentGatewayRequest>>();

        private PaymentGatewayController? _controller;
        private Fixture? _fixture;
        private PaymentGatewayRequest? _request;
        private PaymentGatewayResponse? _response;

        public PaymentGatewayControllerTests()
        {
            _fixture = new Fixture();
            _controller = new PaymentGatewayController(_logger.Object, _service.Object, _validator.Object);
            _request = _fixture.Create<PaymentGatewayRequest>();
            _response = _fixture.Create<PaymentGatewayResponse>();
        }
        [Fact]
        public async Task PostPaymentRequest_Success()
        {
            _service.Setup(s => s.ProcessPayment(_request!, CancellationToken.None))!.ReturnsAsync(_response);
            var validationResults = new ValidationResult();
            _validator.Setup(x => x.ValidateAsync(_request!, CancellationToken.None)).ReturnsAsync(validationResults);

            var result = await _controller!.ProcessPayment(_request!, CancellationToken.None);
            Assert.NotNull(((ObjectResult)result).Value);
        }
        [Fact]
        public void GetId_Success()
        {
            var request = _fixture.Create<PaymentGatewayResponse>();
            _service.Setup(s => s.GetPaymentGatewayDetails(It.Is<Guid>(a => a == request.Id))).Returns(request);
            var result = _controller!.GetPaymentDetails(request.Id);
            Assert.NotNull(((ObjectResult)result).Value);
        }
    }
}
