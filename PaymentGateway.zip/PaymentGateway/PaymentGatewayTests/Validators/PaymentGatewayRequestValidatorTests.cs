﻿using AutoFixture;
using FluentValidation.TestHelper;
using Microsoft.AspNetCore.Mvc;
using PaymentGateway.Models;
using PaymentGateway.Validators;

namespace PaymentGatewayTests.Validators
{
    public class PaymentGatewayRequestValidatorTests
    {
        private PaymentGatewayRequestValidator? _validator;
        private Fixture? _fixture;
        public  PaymentGatewayRequestValidatorTests()
        {
            _validator = new PaymentGatewayRequestValidator();
            _fixture = new Fixture();
        }
        [Fact]
        public void Validation_Success()
        {
            var model = _fixture.Create<PaymentGatewayRequest>();
            model.CardNumber = "1234567891234567";
            model.ExpiryMonth = 1; model.ExpiryYear = 2025;
            model.Cvv = "123";
            model.Currency = "GBP";
            model.Amount = 1;
            var result = _validator.TestValidate(model);
            result.ShouldNotHaveAnyValidationErrors();
        }
        [Fact]
        public void Validation_Error_CardNumber()
        {
            var model = _fixture.Create<PaymentGatewayRequest>();
            model.CardNumber = string.Empty;
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(account => account.CardNumber).WithErrorMessage("CardNumber must not be empty");
        }
        [Fact]
        public void Validation_Error_Cvv()
        {
            var model = _fixture.Create<PaymentGatewayRequest>();
            model.Cvv = string.Empty;
            var result = _validator.TestValidate(model);
            result.ShouldHaveValidationErrorFor(account => account.Cvv).WithErrorMessage("Cvv must not be empty");
        }
       
    }
}
